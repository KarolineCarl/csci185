const canvasWidth = window.innerWidth;
const canvasHeight = window.innerHeight; 

const heart = [
    [0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0],
    [0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 2, 2, 3, 1, 1, 1, 1, 1, 1, 1, 2, 2, 3, 1, 1, 1],
    [1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 1, 1, 1],
    [1, 1, 1, 2, 2, 2, 1, 2, 1, 1, 1, 2, 1, 2, 2, 2, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
    [0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
    [0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0]
];

const frank = [
    [0, 0, 1, 1, 1, 1, 1, 0, 0],
    [0, 0, 2, 2, 2, 2, 2, 0, 0],
    [0, 0, 2, 2, 2, 2, 2, 0, 0],
    [0, 0, 2, 1, 2, 1, 2, 0, 0],
    [0, 0, 2, 2, 2, 2, 2, 0, 0],
    [0, 2, 3, 3, 3, 3, 3, 2, 0],
    [0, 2, 2, 2, 2, 2, 2, 2, 0],
    [0, 2, 2, 2, 2, 2, 2, 2, 0],
    [0, 0, 1, 1, 1, 1, 1, 0, 0],
    [0, 0, 1, 1, 1, 1, 1, 0, 0],
    [0, 0, 2, 2, 0, 2, 2, 0, 0]
];
    
function setup() {
    createCanvas(canvasWidth, canvasHeight);
    drawGrid(canvasWidth, canvasHeight);
     i = 0;
     x = 150;
     y = 150;
     pixel = 25;
     grid = frank;
    while(i < grid.length){
        drawRow(grid[i], x, y, pixel);
        ++i;
        y += pixel;
    }
    i = 0;
     x = 500;
     y = 50;
     pixel = 15;
    grid = heart;
    while(i < grid.length){
        drawRow(grid[i], x, y, pixel);
        ++i;
        y += pixel;
    }
    // first 6 rows of frank
 
   
    drawPixelArt(heart, 20, 20, 15);
    drawPixelArt(frank, 120, 250, 12);
    drawPixelArt(heart, 420, 250, 8);
    drawPixelArt(heart, 55, 415, 6);
    drawPixelArt(heart, 350, 135, 5);
    drawPixelArt(frank, 315, 380, 15);
    drawPixelArt(frank, 420, 10, 10);
}
function drawPixelArt(grid, x, y, pixel){
let i = 0;
while(i < grid.length){
    drawRow(grid[i], x, y, pixel);
    ++i;
    y += pixel;
}}
function drawRow (row, topX, topY,pixelWidth) {
    

    for (let i = 0; i < row.length; i++) {
       let colorNum = row[i];
       if ( colorNum === 0) {noFill();}
else if (colorNum === 1){
fill('pink');}
else if (colorNum === 2){
    fill('black');}
    else if (colorNum === 3){
        fill('white');}
        square(topX, topY, pixelWidth)
        topX += pixelWidth;
    }
}
