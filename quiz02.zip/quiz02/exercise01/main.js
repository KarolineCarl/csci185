function showFox() {
    // your code here...
    console.log('Change image and paragraph to fox...');
    img["src"] = "quiz02/exercise01/images/fox.jpg";
}

function showLion() {
    // your code here...
    console.log('Change image and paragraph to lion...');
}

function showTiger() {
    // your code here...
    console.log('Change image and paragraph to tiger...');
}

function showZebra() {
    // your code here...
    console.log('Change image and paragraph to zebra...');
}

