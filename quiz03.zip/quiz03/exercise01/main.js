function color1() {
    console.log('Change the box\'s background color to red');
    // console.log('Change background to red');
    document.querySelector('#square1').style.backgroundColor = 'red';
}

function color2() {
    console.log('Change the box\'s background color to red');
    // console.log('Change background to red');
    document.querySelector('#square2').style.backgroundColor = 'pink';
}

function color3() {
    console.log('Change the box\'s background color to red');
    // console.log('Change background to red');
    document.querySelector('#square3').style.backgroundColor = 'yellow';
}

function color4() {
    console.log('Change the box\'s background color to red');
    // console.log('Change background to red');
    document.querySelector('#square4').style.backgroundColor = 'blue';
}

function color5() {
    console.log('Change the box\'s background color to red');
    // console.log('Change background to red');
    document.querySelector('#square5').style.backgroundColor = 'orange';
}

function color6() {
    console.log('Change the box\'s background color to red');
    // console.log('Change background to red');
    document.querySelector('#square6').style.backgroundColor = 'green';
}